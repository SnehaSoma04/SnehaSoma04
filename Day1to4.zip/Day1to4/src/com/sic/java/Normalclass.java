package com.sic.java;

public class Normalclass {
	int a = 10;
	static int b =20;
	
	String display() {
		return "Hello Display";
		
	}
	
	public static String display1() {
		return "Hello static display";
		
	}

}
