package com.sic.java;

public class MainClass {
	public static void main(String[] args) {
		Normalclass n1 = new Normalclass();
	    System.out.println(n1.a);
	    n1.display();
	    
	    System.out.println("******************");
	    
	    System.out.println(Normalclass.b);
	    Normalclass.display1();
	
	}

}
