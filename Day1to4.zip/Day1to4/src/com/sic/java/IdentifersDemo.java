package com.sic.java;

public class IdentifersDemo {
	public static void main(String[] args) {
		int $number = 20;
		System.out.println("value of the number variable is : "+$number);
		
		String studentName="Anklet";
		System.out.println("value is : "+ studentName);
	}

}
