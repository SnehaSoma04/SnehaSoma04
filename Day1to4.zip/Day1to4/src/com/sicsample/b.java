package com.sicsample;

public class b {
	static void display() {
		System.out.println("class B displays");
	}

}
