package com.sicsample;

public class instance {
	int a = 10;
	 void display( ) {
		 System.out.println("abc");
	 }
	 public static void main(String args[]) {
		 instance i1 = new instance();
		 System.out.println(i1.a);
		 
		 }

}
