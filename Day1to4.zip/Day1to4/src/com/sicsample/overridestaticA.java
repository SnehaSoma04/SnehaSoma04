package com.sicsample;

public class overridestaticA {
	static void display() {
		System.out.println("class A displays");
	}

}
