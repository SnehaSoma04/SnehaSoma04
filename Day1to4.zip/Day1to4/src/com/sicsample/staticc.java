package com.sicsample;

public class staticc {
	static int b =10;
	static void display() {
		System.out.println("integer");
	}
	public static void main(String args[]) {
		System.out.println(staticc.b);
		staticc.display();
	}

}
