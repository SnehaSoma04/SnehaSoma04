package com.sicsample;

public class access {
	public static void main(String[] args) {
		approach2 a2 = new approach2();
		System.out.println(a2.batsman);
		System.out.println(a2.bowler);
		a2.display();
		approach2.display1();
	}

}
