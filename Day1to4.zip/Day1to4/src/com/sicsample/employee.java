package com.sicsample;

public class employee {
	int empid =1;
	static String empname = "sneha";
	public static void main(String args[]) {
		int empsalary = 30000;
		System.out.println(empsalary);
		employee e1 = new employee();
		System.out.println(e1.empid);
		System.out.println(employee.empname);
		
		
	}
}
