package com.sicsample;

public class approach1 {
	static String batsman = "virat";
	static String bowler = "Bumrah";
	void display( ) {
		System.out.println("cricket");
	}
	static String display1() {
		return "batsman";	
	}
	public static void main(String args[]) {
		approach1 a1 = new approach1();
		System.out.println(a1.batsman);
		a1.display();
		System.out.println(a1.bowler);
		approach1.display1();
	}

}
