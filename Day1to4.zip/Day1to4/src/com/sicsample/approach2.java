package com.sicsample;

public class approach2 {
	static String batsman = "virat";
	static String bowler = "Bumrah";
	void display( ) {
		System.out.println("cricket");
	}
	static String display1() {
		return "batsman";	
	}

}


