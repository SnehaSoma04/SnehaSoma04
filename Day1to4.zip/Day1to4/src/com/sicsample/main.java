package com.sicsample;

public class main {
	public static void main(String args[]) {
		overridestaticA.display();
	}
}
