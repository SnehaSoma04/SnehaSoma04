package com.example.demo.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.entity.Placement;
import com.example.demo.repository.PlacementRepository;

@Service
public class PlacementServiceImpl implements PlacementService {
	@Autowired
	private PlacementRepository placementRepository;

	@Override
	public Placement savePlacement(Placement placement) {
		// TODO Auto-generated method stub
		return placementRepository.save(placement);
	}

	@Override
	public List<Placement> fetchPlacementList() {
		// TODO Auto-generated method stub
		return placementRepository.findAll();
	}

	@Override
	public Placement fetchPlacementById(Long placementId) {
		// TODO Auto-generated method stub
		return placementRepository.findById(placementId).get();
	}

	@Override
	public void deletePlacementById(Long placementId) {
		// TODO Auto-generated method stub
		placementRepository.deleteById(placementId);
	}

	@Override
	public Placement updatePlacement(Long placementId, Placement placement) {
		 Placement depDB = placementRepository.findById(placementId).get();

	       if(Objects.nonNull(placement.getPlacementName()) &&
	       !"".equalsIgnoreCase(placement.getPlacementName())) {
	           depDB.setPlacementName(placement.getPlacementName());
	       }

	      if(placement.getPlacementYear()!=0) {
	    	  depDB.setPlacementYear(placement.getPlacementYear());
	      }

	       if(Objects.nonNull(placement.getPlacementQualification()) &&
	               !"".equalsIgnoreCase(placement.getPlacementQualification())) {
	           depDB.setPlacementQualification(placement.getPlacementQualification());
	       }

	       return placementRepository.save(depDB);
	}
	
	

}
