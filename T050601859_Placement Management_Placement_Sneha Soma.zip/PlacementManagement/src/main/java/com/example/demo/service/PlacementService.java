package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Placement;

public interface PlacementService {

	Placement savePlacement(Placement placement);

	List<Placement> fetchPlacementList();

	Placement fetchPlacementById(Long placementId);

	void deletePlacementById(Long placementId);

	Placement updatePlacement(Long placementId, Placement placement);

	
}
